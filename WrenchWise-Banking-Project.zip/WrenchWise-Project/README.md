# Simulated Real-Time Banking Architecture with Multi-Agent Automation using Experimental Models

An enterprise-grade, full-stack simulated real-time banking platform featuring a **Nine-Layer Banking Architecture**, an autonomous **Multi-Agent Orchestrator** with 9 specialized agents, a **Model Context Protocol (MCP) Tool Sandbox**, an **Enterprise Hybrid Knowledge RAG Engine**, an **Experimental ML Pipeline**, and an **Atomic Double-Entry Banking Transaction Engine**.

---

## 🏛️ 1. Nine-Layer Architecture Diagram

```
+===================================================================================================+
| [LAYER 1] BANKING CHANNELS / USERS                                                               |
|  Mobile Banking (iOS/Android) | Online Web Cockpit | Branch Portal | Call Center | RM Portal      |
+===================================================================================================+
                                                │ (HTTPS / WSS / JWT)
                                                ▼
+===================================================================================================+
| [LAYER 2] API & EXPERIENCE GATEWAY                                                                |
|  FastAPI Gateway │ WAF & Input Validation │ OAuth2 / RBAC │ Correlation ID │ Rate Limiting        |
+===================================================================================================+
                                                │ (Distributed Tracing / Spans)
                                                ▼
+===================================================================================================+
| [LAYER 3] AI GATEWAY & AI CONTROL PLANE                                                          |
|  PII Masking (PAN/SSN) │ Prompt Injection Defense │ FinOps Token Budget │ Model Routing (Exp/Det)  |
+===================================================================================================+
                                                │ (Enriched & Sanitized Prompt)
                                                ▼
+===================================================================================================+
| [LAYER 4] MULTI-AGENT ORCHESTRATION LAYER (SUPERVISOR ENGINE)                                     |
|  Intent Classifier │ Task Decomposition DAG │ Consensus Check │ Timeout & Bounded Retries        |
|  ├── Customer Agent           ├── Banking Product Agent   ├── Risk/Fraud Agent                    |
|  ├── Credit Agent             ├── Compliance Agent        ├── Financial Advisory Agent            |
|  ├── Research Agent           ├── Document Agent          └── Notification Agent                  |
+===================================================================================================+
                                                │ (Least-Privilege JSON-RPC 2.0)
                                                ▼
+===================================================================================================+
| [LAYER 5] AGENT TOOL & MODEL CONTEXT PROTOCOL (MCP) LAYER                                        |
|  MCP Protocol Server (tools/list, tools/call) │ 12 Banking Tools │ Human-In-The-Loop Approval Gates|
|  ├── account_tool   ├── loan_tool        ├── credit_tool      ├── payment_tool                    |
|  ├── crm_tool       ├── kyc_tool         ├── aml_tool         ├── card_tool                       |
|  ├── transaction_tool├── notification_tool├── document_tool  └── core_banking_tool               |
+===================================================================================================+
                         │                                              │
                         ▼                                              ▼
+===================================================+ +=============================================+
| [LAYER 6] ENTERPRISE DATA & TRANSACTION ENGINE   | | [LAYER 7] KNOWLEDGE / RAG SYSTEM            |
|  Double-Entry Ledger (Balanced DEBIT/CREDIT)     | |  Hybrid Okapi BM25 + Vector Cosine          |
|  Atomic Balance Locks │ Idempotency Deduplication | |  Reciprocal Rank Fusion (RRF) Reranking     |
|  Reconciliation Audit │ Event Stream (Redis/Bus) | |  Statutory Citations (FATF, OFAC, BCBS)     |
+===================================================+ +=============================================+
                         │                                              │
                         ▼                                              ▼
+===================================================================================================+
| [LAYER 8] ENTERPRISE SERVICE ADAPTERS (SIMULATED EXTERNAL ECOSYSTEM)                              |
|  Credit Bureau Gateway │ Payment Networks (Fedwire, ACH, SWIFT) │ KYC/AML Sanctions Lists        |
|  Government Tax/SSN API │ Market Rates (SOFR, Yield Curve)      │ Twilio/SendGrid Gateways        |
|  *Deterministic Fault Injection Support: SIMULATE_TIMEOUT (504), SIMULATE_503, SIMULATE_429      |
+===================================================================================================+
                                                │
                                                ▼
+===================================================================================================+
| [LAYER 9] CROSS-CUTTING PRODUCTION PLATFORM                                                       |
|  Structured JSON Logging │ OpenTelemetry Spans │ Prometheus Latency Metrics │ Audit Immutability  |
+===================================================================================================+
```

---

## 🗄️ 2. Database ER Diagram

The transaction engine enforces **strict double-entry bookkeeping** where no money is ever created or destroyed. Every transaction generates at least two balanced ledger entries (DEBIT and CREDIT) that sum to zero.

```mermaid
erDiagram
    USERS ||--o{ ACCOUNTS : owns
    USERS {
        string id PK
        string email UK
        string full_name
        string role
        string hashed_password
        datetime created_at
    }

    ACCOUNTS ||--o{ TRANSACTIONS : participates
    ACCOUNTS ||--o{ LEDGER_ENTRIES : posted_to
    ACCOUNTS {
        string account_number PK
        string user_id FK
        string account_type
        decimal balance
        decimal available_balance
        string currency
        string status
        int version
    }

    TRANSACTIONS ||--|{ LEDGER_ENTRIES : generates
    TRANSACTIONS {
        string id PK
        string reference_id UK
        string idempotency_key UK
        string source_account FK
        string destination_account FK
        decimal amount
        string currency
        string transaction_type
        string status
        decimal risk_score
        datetime created_at
    }

    LEDGER_ENTRIES {
        string id PK
        string transaction_id FK
        string account_number FK
        string entry_type
        decimal amount
        decimal balance_after
        datetime created_at
    }

    AUDIT_LOGS {
        string id PK
        string trace_id
        string tool_name
        string invoking_agent
        string request_payload
        string response_payload
        int latency_ms
        boolean success
        datetime created_at
    }

    HITL_TICKETS {
        string id PK
        string transaction_id FK
        string reason
        string severity
        string status
        string assigned_reviewer
        datetime created_at
    }
```

---

## 🔄 3. Multi-Agent Workflow Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    actor User as Banking User / RM
    participant L2 as Layer 2: API Gateway
    participant L3 as Layer 3: AI Control Plane
    participant L4 as Layer 4: Supervisor Orchestrator
    participant Agents as Specialized Agents (1-9)
    participant L5 as Layer 5: MCP Tool Registry
    participant L6 as Layer 6: Core Ledger
    participant L8 as Layer 8: External Adapters

    User->>L2: POST /api/v1/agents/chat (Prompt: "Wire $49,990 to Nassau Ltd")
    L2->>L3: Forward with Correlation Trace ID
    Note over L3: PII Masking (SSN, PAN)<br/>Adversarial Injection Defense<br/>FinOps Token Accounting
    L3->>L4: Sanitized Request + Security Pass
    Note over L4: Intent Classifier: SUSPICIOUS_TRANSACTION<br/>Build Dependency Execution DAG
    L4->>Agents: Invoke Customer Agent (Verify Balance & History)
    Agents->>L5: tools/call: account_tool
    L5->>L6: Query cleared balance & locks
    L6-->>L5: Balance OK ($145,200.00)
    L5-->>Agents: Account Verified
    
    L4->>Agents: Invoke Risk/Fraud Agent (Multi-Model ML Anomaly Scoring)
    Agents->>L5: tools/call: transaction_tool (Velocity & Geo)
    L5-->>Agents: Anomaly Score: 0.94 (Critical)
    
    L4->>Agents: Invoke Compliance Agent (OFAC/PEP Sanctions Screening)
    Agents->>L5: tools/call: aml_tool ("Nassau Maritime Holdings Ltd")
    L5->>L8: Screen simulated OFAC SDN database
    L8-->>L5: High-Risk Flagged Jurisdiction
    L5-->>Agents: Compliance Risk High
    
    Note over L4: Layer 3 HITL Trigger Evaluated:<br/>Score >= 75 or Amount >= $25,000<br/>Create Approval Ticket
    L4->>L5: tools/call: notification_tool
    L5-->>Agents: Multi-Channel Alert Sent (SMS, Email)
    
    L4-->>L2: AgentTrajectoryResponse (verdict: FLAGGED_HUMAN_REVIEW, hitl_ticket_id: TKT-xxx)
    L2-->>User: Structured Response with Step-by-Step Trajectory
```

---

## 📋 4. The Nine Specialized Agents

| # | Agent Name | Primary Responsibility | Authorized MCP Tools |
| :--- | :--- | :--- | :--- |
| 1 | **Customer Agent** | Customer 360 profile, KYC tier, account listing, balance inquiry. | `account_tool`, `crm_tool`, `card_tool`, `transaction_tool` |
| 2 | **Banking Product Agent** | Savings accounts, certificates of deposit, loans, cards, APY tiers. | `loan_tool`, `crm_tool` |
| 3 | **Risk/Fraud Agent** | Anomaly detection, velocity scoring, ML pipeline consensus. | `transaction_tool`, `account_tool`, `card_tool` |
| 4 | **Credit Agent** | Bureau integration, debt-to-income (DTI), APR pricing, loan underwriting. | `credit_tool`, `loan_tool` |
| 5 | **Compliance Agent** | AML screening, PEP lists, OFAC watchlists, FinCEN CTR/SAR policy. | `aml_tool`, `kyc_tool` |
| 6 | **Financial Advisory Agent** | Cash cushion analysis, wealth planning, asset allocation, portfolio yields. | `account_tool`, `crm_tool` |
| 7 | **Research Agent** | Market intelligence, Federal Reserve SOFR benchmarks, macro Treasury curves. | `core_banking_tool`, `document_tool` |
| 8 | **Document Agent** | Ingestion, OCR parsing, payslip verification, bank statement analysis. | `document_tool` |
| 9 | **Notification Agent** | Security alerts, multi-channel customer communications (SMS, Push, Email).| `notification_tool` |

---

## 🔬 5. Model Evaluation Methodology & Limitations

### Benchmark Methodology
The platform evaluates fraud detection models using a reproducible synthetic dataset of transaction feature vectors generated with fixed seed `42`:
- **Stratified Train/Test Split**: 70/30 split preserving minority fraud class distribution without test leakage.
- **Features Evaluated**: Transaction Amount, Hour of Day, 1-Hour Velocity, 24-Hour Velocity, Geolocation Distance from Home (km), Device Risk Score, Is New Counterparty, International Flag, and Failed PIN Attempts.

### Comparative Architecture Results

| Model Architecture | Precision | Recall | F1-Score | FPR | ROC-AUC | p50 Latency | Primary Use-Case |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Rule-Based Baseline** | **100.0%** | 58.3% | 0.737 | **0.00%** | 0.792 | **0.007 ms** | Deterministic sanity checks & velocity blocks |
| **Isolation Forest** | 80.0% | **100.0%** | 0.889 | 2.11% | 0.989 | 13.39 ms | Unsupervised zero-day novel anomaly discovery |
| **Random Forest Ensemble** | **100.0%** | **100.0%** | **1.000** | **0.00%** | **1.000** | 7.82 ms | Supervised consensus & pattern classification |

### Feature Importance (Mean Decrease in Impurity - MDI)
- `distance_from_home_km`: **34.4%**
- `device_risk_score`: **23.1%**
- `amount`: **18.9%**
- `velocity_1h`: **11.5%**
- `is_new_counterparty`: **6.2%**

### Population Drift Monitoring (PSI)
Population Stability Index (PSI) is continuously computed on live transaction vectors against the baseline distribution. All features maintain PSI < 0.05 (`STABLE`), proving no model degradation.

### Known Limitations of Experimental ML
1. **Synthetic Data**: Trained on simulated distributions; real-world payment fraud exhibits higher class imbalance (~0.01% fraud rate vs 8% synthetic).
2. **Deterministic Ledger Decoupling**: Machine learning predictions **never** directly mutate account balances. All financial debit/credit movements strictly require deterministic double-entry ledger invariant validation.

---

## 🛡️ 6. Security Design & Production Controls

1. **Least-Privilege Tool Authorization**:
   - Every tool registered in the central MCP registry explicitly defines its `authorized_agents`.
   - Any agent attempting to invoke an unauthorized tool is immediately blocked with an immutable audit entry (`Security Violation: Agent <X> lacks permission for tool <Y>`).
2. **PII Masking & Sanitization**:
   - Layer 3 AI Gateway parses all input prompts with high-performance regular expressions.
   - Primary Account Numbers (PANs / credit cards) are masked to `••••-••••-••••-XXXX`.
   - Social Security Numbers (SSNs) are masked to `XXX-XX-••••`.
   - Emails are redacted before reaching model inference.
3. **Adversarial Prompt Injection Defense**:
   - Both user prompts and retrieved RAG knowledge chunks are screened for adversarial override strings (`ignore previous instructions`, `bypass guardrails`, `reveal system prompt`).
   - Flagged prompts trigger safety score drops (< 50/100) and are rerouted to deterministic safe fallbacks.
4. **Idempotency Protection**:
   - Financial transfers require an `Idempotency-Key` HTTP header. Duplicate requests return the original transaction receipt without re-executing ledger entries.
5. **Human-In-The-Loop (HITL) Review Gates**:
   - Transfers $\ge \$25,000$, transactions with fraud score $\ge 75/100$, or OFAC sanctions matches automatically create an approval ticket and pause autonomous clearing.

---

## 🧪 7. Test Plan & Actual Results (46/46 Passed - 100%)

The automated test suite covers all 9 architectural layers and all End-to-End Acceptance Criteria A through J:

```bash
cd backend
.\venv\Scripts\python.exe -m pytest tests/ -v
```

### Verified Test Breakdown:
- **`tests/test_banking_engine.py` (10/10 PASSED)**:
  - `test_successful_deposit`: Account credit and ledger balance consistency.
  - `test_successful_withdrawal`: Account debit and balance check.
  - `test_insufficient_funds_rejection`: Safe overdraft rejection without ledger damage.
  - `test_invalid_account_handling`: Non-existent account validation.
  - `test_account_to_account_transfer`: Atomic transfer between two accounts.
  - `test_idempotency_prevents_duplicate_transfer`: Deduplication via unique idempotency key.
  - `test_double_entry_balanced_legs`: Exact debit/credit parity ($\Sigma \text{debits} = \Sigma \text{credits}$).
  - `test_reconciliation_audit`: Zero-variance general ledger audit.
  - `test_transaction_search_and_pagination`: Filtered range search and cursor pagination.
  - `test_auth_and_rbac`: JWT bearer authentication and role-based permissions.
- **`tests/test_multi_agent.py` (9/9 PASSED)**:
  - `test_agent_routing_balance_query`: Customer Agent isolation.
  - `test_agent_routing_loan_simulation`: Multi-agent credit underwriting DAG.
  - `test_agent_routing_suspicious_transfer`: Risk/Fraud + Compliance + Notification collaboration.
  - `test_tool_authorization_enforcement`: Least privilege access enforcement.
  - `test_deterministic_llm_adapter_offline`: Safe execution when external LLM API key is empty.
  - `test_all_seven_demonstration_scenarios`: All 7 demonstration presets run cleanly.
  - `test_workflow_cancellation`: Graceful supervisor workflow cancellation.
  - `test_tool_audit_logging`: Immutable audit trail verification.
  - `test_registered_tools_schema`: Pydantic JSON schema introspection.
- **`tests/test_prompt4_mcp_rag_ml.py` (12/12 PASSED)**:
  - `test_all_12_mcp_tools_and_schemas`: Verification of all 12 MCP tools.
  - `test_mcp_protocol_jsonrpc`: JSON-RPC 2.0 protocol handler (`initialize`, `tools/list`, `tools/call`).
  - `test_tool_permission_enforcement`: Security violation checks.
  - `test_sensitive_action_human_approval`: High-value transfer HITL escalation.
  - `test_external_services_mock_adapters_and_failures`: Mock adapters with 504/503/429 fault injection.
  - `test_rag_hybrid_retrieval_and_citations`: BM25 + Vector cosine + RRF reranking.
  - `test_rag_prompt_injection_sanitization`: Adversarial prompt injection neutralization.
  - `test_rag_document_ingestion`: Semantic chunking and versioning.
  - `test_ml_dataset_and_no_leakage`: Deterministic seed 42 split verification.
  - `test_ml_models_benchmark_and_evaluation`: Performance evaluation across 3 model types.
  - `test_live_transaction_risk_prediction`: Multi-model live feature vector scoring.
  - `test_deterministic_transaction_safety`: Mathematical decoupling of ledger and ML scores.
- **`tests/test_prompt5_e2e_acceptance.py` (11/11 PASSED)**:
  - `test_acceptance_a_successful_transfer_updates_ledger`: Ledger leg balance verification.
  - `test_acceptance_b_insufficient_balance_rejected_safely`: Safe overdraft rejection.
  - `test_acceptance_c_idempotency_prevents_duplicate_transfer`: Deduplication enforcement.
  - `test_acceptance_d_suspicious_transaction_risk_and_audit`: Supervisor routing + HITL ticket creation.
  - `test_acceptance_e_supervisor_agent_routing`: Intent routing to authorized customer agent.
  - `test_acceptance_f_unauthorized_tool_call_rejected`: Tool call without authorization blocked.
  - `test_acceptance_g_policy_query_citations`: Policy search with legal citations.
  - `test_acceptance_h_model_evaluation_reproducible`: Seed 42 benchmark reproducibility.
  - `test_acceptance_i_notifications_and_delivery_status`: Multi-channel dispatch with DELIVERED status.
  - `test_acceptance_j_audit_trail_end_to_end_traceability`: Comprehensive caller and latency audit.
  - `test_production_controls_pii_masking`: PII masking of SSN and Card numbers.
- **`tests/test_api.py` (4/4 PASSED)**:
  - `test_health_check`: REST API health status.
  - `test_get_accounts`: Account listing API.
  - `test_agent_orchestration_loan`: End-to-end loan orchestration.
  - `test_agent_orchestration_fraud`: End-to-end fraud orchestration.

---

## 🚀 8. Setup & Startup Instructions

### Prerequisites
- **Python**: 3.11+
- **Node.js**: 20+
- **Docker & Docker Compose** (Optional for containerized mode)

### Option A: Local Development Setup (Quickstart)

```bash
# 1. Clone repository & enter project directory
cd simulated-banking-system

# 2. Start Backend
cd backend
python -m venv venv
# On Windows:
.\venv\Scripts\activate
# On Linux/macOS:
# source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload

# 3. Start Frontend (New Terminal)
cd ../frontend
npm install
npm run dev -- --port 5173
```
- Frontend Cockpit: `http://localhost:5173`
- Backend Swagger UI: `http://127.0.0.1:8000/docs`

### Option B: Docker Compose Deployment

```bash
docker compose up --build -d
```
Services started:
- `horizon_banking_db`: PostgreSQL 16 with `pgvector` on port `5432`
- `horizon_banking_redis`: Redis 7 Streams on port `6379`
- `horizon_banking_backend`: FastAPI on port `8000`
- `horizon_banking_frontend`: Nginx serving production bundle on port `5173`

---

## 🎬 9. Five-Minute Demonstration Script

| Minute | Feature Area | Step-by-Step Actions | Expected Observable Result |
| :---: | :--- | :--- | :--- |
| **00:00 - 01:00** | **Banking Core & Accounts** | 1. Navigate to **Accounts & Balances**.<br/>2. View checking and savings liquidity.<br/>3. Switch to **Transfer & Cash Engine** and execute a $500 transfer to `ACC-2009812`. | Balances update instantly; double-entry ledger records balanced DEBIT and CREDIT journal legs in **Double-Entry Ledger**. |
| **01:00 - 02:00** | **Multi-Agent Orchestrator** | 1. Open **Agent Command Center**.<br/>2. Click preset: *"Suspicious High-Value Wire to Cyprus"*.<br/>3. Click **Execute Workflow**. | Supervisor classifies intent, decomposes task across Risk/Fraud, Compliance, and Notification agents; flags transaction for human review. |
| **02:00 - 03:00** | **Tool Registry & MCP Server** | 1. Navigate to **Tool Registry & MCP**.<br/>2. Inspect schemas for all 12 banking tools.<br/>3. Open interactive **MCP JSON-RPC 2.0 Console** and run `tools/list`. | JSON-RPC 2.0 response displays all tool specifications, permissions, and parameters; audit trail logs execution time. |
| **03:00 - 04:00** | **RAG Knowledge & Citations** | 1. Open **Knowledge Base & RAG**.<br/>2. Search for *"FATF wire transfer reporting"*.<br/>3. Inspect citation pills and hybrid scores. | Returns statutory citation (`FATF Standards §16.3`, Version `2.4`) and semantic match score with prompt injection defense active. |
| **04:00 - 05:00** | **ML Experiments & Risk Scoring** | 1. Open **Model Experiments** and click **Run Benchmark (Seed 42)**.<br/>2. Switch to **Risk Assessment** simulator and drag `Velocity (1h)` and `Distance` sliders. | Side-by-side benchmark updates with Precision, Recall, and ROC-AUC; composite risk score dynamically updates in real-time. |

---

## ⚠️ 10. Known Limitations & Future Improvements

1. **Synthetic Data Realism**:
   - Current ML models train on synthetic transaction vectors generated via statistical sampling.
   - *Future Work*: Integrate anonymized real-world open banking datasets (e.g., PaySim or IEEE-CIS Fraud Detection).
2. **External Service Live Sandbox**:
   - External services (Fedwire, Experian, OFAC) operate via high-fidelity mock adapters with configurable latency and error injection.
   - *Future Work*: Add live client connectors for Plaid, Stripe Treasury, and real-time OFAC API endpoints.
3. **Distributed Clustering**:
   - Background tasks utilize Redis Streams when available with an automatic in-memory queue fallback for zero-dependency local development.
   - *Future Work*: Add Kubernetes Helm charts for multi-replica horizontal autoscaling and distributed consensus locking.
